import 'package:flutter/material.dart';

void main() {
  runApp(TokoAhMengApp());
}

class TokoAhMengApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TokoAhMeng',
      theme: ThemeData(
        primaryColor: Color(0xFF1A3855),
        scaffoldBackgroundColor: Colors.white,
        appBarTheme: AppBarTheme(
          backgroundColor: Color(0xFF1A3855),
          foregroundColor: Colors.white,
        ),
        fontFamily: 'Roboto',
      ),
      home: HomePage(),
      routes: {
        '/productList': (context) => ProductListPage(),
        '/productDetail': (context) => ProductDetailPage(),
      },
    );
  }
}

class Category {
  final String name;
  final IconData icon;
  Category({required this.name, required this.icon});
}

class Product {
  final String name;
  final double price;
  final IconData icon;
  final String category;
  final String description;

  Product({
    required this.name,
    required this.price,
    required this.icon,
    required this.category,
    this.description = '',
  });
}

final List<Category> categories = [
  Category(name: 'Makanan', icon: Icons.fastfood),
  Category(name: 'Minuman', icon: Icons.local_drink),
  Category(name: 'Elektronik', icon: Icons.phone_android),
  Category(name: 'Pakaian', icon: Icons.checkroom),
  Category(name: 'Aksesoris', icon: Icons.watch),
];

final List<Product> products = [
  // 8 Produk Makanan
  Product(name: 'Nasi Goreng', price: 15000, icon: Icons.fastfood, category: 'Makanan', description: 'Nasi goreng spesial gurih dan pedas.'),
  Product(name: 'Sate Ayam', price: 18000, icon: Icons.restaurant_menu, category: 'Makanan', description: 'Sate ayam dengan bumbu kacang lezat.'),
  Product(name: 'Bakso', price: 16000, icon: Icons.lunch_dining, category: 'Makanan', description: 'Bakso isi daging sapi dan kuah kaldu.'),
  Product(name: 'Mie Goreng', price: 14000, icon: Icons.ramen_dining, category: 'Makanan', description: 'Mie goreng pedas, toping telur puyuh.'),
  Product(name: 'Rendang', price: 24000, icon: Icons.dining, category: 'Makanan', description: 'Daging sapi rendang Padang bumbu rempah.'),
  Product(name: 'Gado-Gado', price: 12500, icon: Icons.eco, category: 'Makanan', description: 'Gado-gado sayur segar dan saus kacang.'),
  Product(name: 'Pecel Lele', price: 17000, icon: Icons.set_meal, category: 'Makanan', description: 'Lele goreng, sambal, dan lalapan segar.'),
  Product(name: 'Ayam Geprek', price: 19000, icon: Icons.food_bank, category: 'Makanan', description: 'Ayam geprek sambal super pedas.'),

  // 8 Produk Minuman
  Product(name: 'Air Mineral', price: 5000, icon: Icons.local_drink, category: 'Minuman', description: 'Air minum sehat dan segar.'),
  Product(name: 'Kopi Hitam', price: 8000, icon: Icons.coffee, category: 'Minuman', description: 'Kopi hitam premium tanpa gula.'),
  Product(name: 'Es Teh Manis', price: 7000, icon: Icons.icecream, category: 'Minuman', description: 'Es teh manis segar, gula aren.'),
  Product(name: 'Jus Alpukat', price: 12000, icon: Icons.energy_savings_leaf, category: 'Minuman', description: 'Jus alpukat segar dan krim coklat.'),
  Product(name: 'Susu Coklat', price: 9500, icon: Icons.local_cafe, category: 'Minuman', description: 'Susu sapi full cream dan coklat.'),
  Product(name: 'Lemon Tea', price: 9000, icon: Icons.bubble_chart, category: 'Minuman', description: 'Teh lemon, dingin, segar.'),
  Product(name: 'Soda Gembira', price: 10000, icon: Icons.local_bar, category: 'Minuman', description: 'Soda, sirup, dan susu kental manis.'),
  Product(name: 'Matcha Latte', price: 12500, icon: Icons.local_cafe, category: 'Minuman', description: 'Teh matcha premium, aroma wangi.'),

  // 8 Produk Elektronik
  Product(name: 'Smartphone', price: 2500000, icon: Icons.smartphone, category: 'Elektronik', description: 'Smartphone Android generasi terbaru.'),
  Product(name: 'Headphone', price: 350000, icon: Icons.headphones, category: 'Elektronik', description: 'Headphone suara jernih dan bass.'),
  Product(name: 'Powerbank', price: 120000, icon: Icons.battery_charging_full, category: 'Elektronik', description: 'Powerbank 10.000mAh super fast.'),
  Product(name: 'Laptop', price: 4300000, icon: Icons.laptop, category: 'Elektronik', description: 'Laptop slim, RAM 8GB, SSD 256GB.'),
  Product(name: 'Monitor LED', price: 1100000, icon: Icons.desktop_windows, category: 'Elektronik', description: 'Monitor LED 24 inch Full HD.'),
  Product(name: 'Printer', price: 599000, icon: Icons.print, category: 'Elektronik', description: 'Printer inkjet warna ekonomis.'),
  Product(name: 'Smartwatch', price: 550000, icon: Icons.watch, category: 'Elektronik', description: 'Smartwatch sensor suhu & detak.'),
  Product(name: 'Speaker Bluetooth', price: 210000, icon: Icons.speaker, category: 'Elektronik', description: 'Speaker bluetooth portable.'),

  // 8 Produk Pakaian
  Product(name: 'Kaos Polos', price: 65000, icon: Icons.checkroom, category: 'Pakaian', description: 'Kaos polos bahan cotton nyaman.'),
  Product(name: 'Jaket Bomber', price: 165000, icon: Icons.dry_cleaning, category: 'Pakaian', description: 'Jaket bomber stylish dan hangat.'),
  Product(name: 'Kemeja Flanel', price: 95000, icon: Icons.hiking, category: 'Pakaian', description: 'Kemeja flanel motif kotak.'),
  Product(name: 'Celana Jeans', price: 120000, icon: Icons.branding_watermark, category: 'Pakaian', description: 'Celana jeans slim fit klasik.'),
  Product(name: 'Hoodie', price: 99000, icon: Icons.face_6, category: 'Pakaian', description: 'Hoodie cotton unisex warna polos.'),
  Product(name: 'Seragam Futsal', price: 125000, icon: Icons.sports_soccer, category: 'Pakaian', description: 'Seragam futsal kualitas jersey premium.'),
  Product(name: 'Topi Baseball', price: 40000, icon: Icons.umbrella, category: 'Pakaian', description: 'Topi baseball adjustable, nyaman.'),
  Product(name: 'Polo Shirt', price: 95000, icon: Icons.radar, category: 'Pakaian', description: 'Polo shirt classy bahan halus.'),

  // 8 Produk Aksesoris
  Product(name: 'Jam Tangan', price: 299000, icon: Icons.watch, category: 'Aksesoris', description: 'Jam tangan stylish anti air.'),
  Product(name: 'Gelang Kulit', price: 39000, icon: Icons.refresh, category: 'Aksesoris', description: 'Gelang kulit simple elegan.'),
  Product(name: 'Cincin Perak', price: 100000, icon: Icons.radio_button_unchecked, category: 'Aksesoris', description: 'Cincin perak asli, ukuran adjustable.'),
  Product(name: 'Kacamata Hitam', price: 60000, icon: Icons.remove_red_eye, category: 'Aksesoris', description: 'Kacamata hitam anti UV.'),
  Product(name: 'Tali HP', price: 12000, icon: Icons.link, category: 'Aksesoris', description: 'Tali HP kuat dan stylish.'),
  Product(name: 'Tas Selempang', price: 83000, icon: Icons.backpack, category: 'Aksesoris', description: 'Tas selempang trendy dan simpel.'),
  Product(name: 'Anting Fashion', price: 27000, icon: Icons.wifi_tethering, category: 'Aksesoris', description: 'Anting fashion model unik.'),
  Product(name: 'Pin Bros', price: 15000, icon: Icons.brightness_5, category: 'Aksesoris', description: 'Pin bros custom karakter lucu.'),
];

Set<String> favoriteProducts = {};

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'TokoAhMeng - Home',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 24,
            fontFamily: 'Roboto',
            letterSpacing: 1.2,
          ),
        ),
        centerTitle: true,
        elevation: 0.0,
      ),
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF223A59),
              Color(0xFF344D62),
              Colors.white,
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            stops: [0.0, 0.3, 1.0],
          ),
        ),
        child: ListView.builder(
          itemCount: categories.length,
          padding: EdgeInsets.symmetric(vertical: 25, horizontal: 0),
          itemBuilder: (context, index) {
            final cat = categories[index];
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 8),
              child: Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: ListTile(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  leading: Icon(cat.icon, color: Color(0xFF2464B1), size: 32),
                  title: Text(
                    cat.name,
                    style: TextStyle(
                      fontWeight: FontWeight.w500,
                      fontSize: 18,
                      fontFamily: 'Roboto',
                    ),
                  ),
                  trailing: Icon(Icons.arrow_forward_ios, size: 20, color: Color(0xFF2464B1)),
                  onTap: () {
                    Navigator.pushNamed(context, '/productList', arguments: cat.name);
                  },
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class ProductListPage extends StatefulWidget {
  @override
  _ProductListPageState createState() => _ProductListPageState();
}

class _ProductListPageState extends State<ProductListPage> {
  late String category;
  List<Product> filteredProducts = [];
  String sortOption = 'Nama';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    category = ModalRoute.of(context)!.settings.arguments as String;
    filteredProducts = products.where((p) => p.category == category).toList();
    sortProducts(sortOption);
  }

  void sortProducts(String option) {
    setState(() {
      sortOption = option;
      if (option == 'Harga Terendah') {
        filteredProducts.sort((a, b) => a.price.compareTo(b.price));
      } else if (option == 'Harga Tertinggi') {
        filteredProducts.sort((a, b) => b.price.compareTo(a.price));
      } else {
        filteredProducts.sort((a, b) => a.name.compareTo(b.name));
      }
    });
  }

  void toggleFavorite(String productName) {
    setState(() {
      if (favoriteProducts.contains(productName)) {
        favoriteProducts.remove(productName);
      } else {
        favoriteProducts.add(productName);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    int crossAxisCount = MediaQuery.of(context).size.width > 600 ? 4 : 2;
    double size = 180;

    return Scaffold(
      appBar: AppBar(
        title: Text('Produk $category'),
        elevation: 0,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            child: DropdownButton<String>(
              value: sortOption,
              items: <String>['Nama', 'Harga Terendah', 'Harga Tertinggi']
                  .map((value) => DropdownMenuItem(
                        value: value,
                        child: Text('Sort by $value'),
                      ))
                  .toList(),
              onChanged: (value) {
                if (value != null) sortProducts(value);
              },
            ),
          ),
          Expanded(
            child: GridView.count(
              crossAxisCount: crossAxisCount,
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 8),
              children: filteredProducts.map((product) {
                return Center(
                  child: Stack(
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pushNamed(context, '/productDetail', arguments: product);
                        },
                        child: Container(
                          width: size,
                          height: size,
                          child: Card(
                            elevation: 4,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              side: BorderSide(color: Color(0xFF2464B1), width: 2.3),
                            ),
                            child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  SizedBox(height: 10),
                                  Icon(product.icon, size: 48, color: Color(0xFF2464B1)),
                                  SizedBox(height: 20),
                                  Text(
                                    product.name,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      fontFamily: 'Roboto',
                                    ),
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    'Rp ${product.price.toInt()}',
                                    style: TextStyle(color: Colors.grey[700], fontSize: 14),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        right: 17,
                        top: 17,
                        child: GestureDetector(
                          onTap: () => toggleFavorite(product.name),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 2)],
                              border: Border.all(color: Colors.grey[300]!, width: 1.2),
                            ),
                            child: Padding(
                              padding: EdgeInsets.all(4),
                              child: Icon(
                                favoriteProducts.contains(product.name)
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                                color: Colors.red,
                                size: 19,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class ProductDetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Product product = ModalRoute.of(context)!.settings.arguments as Product;
    final double width = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Produk'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 26),
          child: Column(
            children: [
              Container(
                width: width < 400 ? width - 32 : 220,
                height: width < 400 ? width - 32 : 220,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: Color(0xFF2464B1), width: 3),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Icon(product.icon, size: 120, color: Color(0xFF2464B1)),
                ),
              ),
              SizedBox(height: 24),
              Card(
                elevation: 3,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 24),
                  child: Column(
                    children: [
                      Text(
                        product.name,
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22, fontFamily: 'Roboto'),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Rp ${product.price.toInt()}',
                        style: TextStyle(fontSize: 18, color: Color(0xFF2464B1)),
                      ),
                      Divider(thickness: 1.5, color: Colors.grey[300]),
                      SizedBox(height: 10),
                      Text(
                        product.description,
                        style: TextStyle(fontSize: 16, color: Colors.black87),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
